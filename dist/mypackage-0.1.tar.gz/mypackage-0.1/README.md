# mypackage
This is an example on how to publish a python package

# How to install
